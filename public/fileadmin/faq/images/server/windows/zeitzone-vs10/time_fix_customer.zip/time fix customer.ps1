if (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) { Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit }

New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\TimeProviders\NtpClient" -Name "SpecialPollInterval" -PropertyType DWord -Value "3800" -Force
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\TimeZoneInformation" -Name "RealTimeIsUniversal" -PropertyType DWord -Value "00000001" -Force

Set-Service -Name "w32time" -StartupType Automatic
Restart-Service -Name "w32time" -Force

Stop-Service -Name "w32time" -Force
w32tm /config /syncfromflags:manual /manualpeerlist:"0.it.pool.ntp.org 1.it.pool.ntp.org 2.it.pool.ntp.org 3.it.pool.ntp.org"
Start-Service -Name "w32time"

w32tm /config /update
w32tm /resync /rediscover
w32tm /resync /rediscover
w32tm /resync /rediscover